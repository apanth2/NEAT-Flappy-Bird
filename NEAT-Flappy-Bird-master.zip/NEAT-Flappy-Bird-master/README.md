# NEAT-Flappy-Bird
An AI that plays flappy bird! Using the NEAT python module.

# Instructions
Simply run *flappy_bird.py* and watch an AI start training itself to play the game of flappy bird!


